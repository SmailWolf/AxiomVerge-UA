@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AxiomVerge-UA.ps1"
if errorlevel 1 (
  echo.
  echo Installation did not complete. Read the message above.
  pause
)
endlocal
