$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select the Axiom Verge game folder containing AxiomVerge.exe'
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host 'Restore cancelled.'
        exit 1
    }
    $game = $dialog.SelectedPath
    $exe = Join-Path $game 'AxiomVerge.exe'
    $backup = Join-Path $game 'Axiom Verge UA backup'
    $statePath = Join-Path $backup 'install-state.json'
    if (!(Test-Path -LiteralPath $exe) -or !(Test-Path -LiteralPath $statePath)) {
        throw 'No completed Ukrainian patch installation was found in the selected folder.'
    }
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $currentHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $exe).Hash.ToLowerInvariant()
    if ($currentHash -ne $state.installedExeSha256) {
        throw 'The game EXE has changed since installation. Restore stopped to avoid overwriting your changes.'
    }
    $sourceFonts = Join-Path $game 'Content\Art\Textures\UI\Fonts'
    Copy-Item -LiteralPath (Join-Path $backup 'AxiomVerge.exe') -Destination $exe -Force
    foreach ($font in @('LucidaConsole6XNA.xnb', 'LucidaConsole8XNA.xnb', 'Moire16XNA.xnb')) {
        Copy-Item -LiteralPath (Join-Path $backup $font) -Destination (Join-Path $sourceFonts $font) -Force
    }
    Remove-Item -LiteralPath $statePath -Force
    Write-Host 'Original game files restored. The backup folder was kept.' -ForegroundColor Green
    Read-Host 'Press Enter to close'
    exit 0
} catch {
    Write-Host "Restore error: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
