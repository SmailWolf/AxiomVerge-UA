#!/usr/bin/env python3
"""Apply translation-only JSON to XML extracted from the user's local game."""
from pathlib import Path
import json
import sys
import xml.etree.ElementTree as ET


def load_translations(path: Path) -> list[dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return [data[k] for k in sorted(data, key=lambda x: int(x))]


def patch_xml(source: Path, target: Path, translation_file: Path) -> int:
    table = load_translations(translation_file)
    parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    root = ET.fromstring(source.read_bytes(), parser=parser)
    if source.name == "Credits_English.xml":
        by_title = {item["key"]: item["translation"] for item in table}
        count = 0
        for node in root.iter():
            if node.tag == "THCreditSection" and node.get("mTitle") in by_title:
                node.set("mTitle", by_title[node.get("mTitle")])
                count += 1
            elif node.tag == "THCreditsEntry" and (node.text or "").strip() == "YOU":
                node.text = "ВАМ"
                count += 1
    else:
        nodes = [n for n in root.iter() if n.tag in ("THTextEntry", "THCutscenePage") and (n.text or "").strip()]
        if len(nodes) != len(table):
            raise ValueError(f"{source.name}: очікували {len(table)} записів, знайдено {len(nodes)}")
        for node, entry in zip(nodes, table):
            node.text = entry["translation"].replace("\\n", "\n")
        count = len(nodes)
    target.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(target, encoding="utf-8", xml_declaration=True)
    return count


def main() -> None:
    original, output, translations = map(Path, sys.argv[1:4])
    total = 0
    for source in sorted(original.glob("*_English.xml")):
        name = source.stem.removesuffix("_English")
        translation_file = translations / f"{name}.json"
        if not translation_file.is_file():
            continue
        total += patch_xml(source, output / source.name, translation_file)
    if total < 800:
        raise SystemExit(f"Застосовано лише {total} текстових записів; патч зупинено.")
    print(f"Перекладено записів титрів і текстів: {total}")


if __name__ == "__main__":
    main()
