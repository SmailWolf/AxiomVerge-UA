from pathlib import Path
import struct
class Reader:
 def __init__(self,b):self.b=b;self.p=10
 def n(self,fmt):
  v=struct.unpack_from('<'+fmt,self.b,self.p);self.p+=struct.calcsize('<'+fmt);return v[0] if len(v)==1 else v
 def vi(self):
  n=0;s=0
  while True:
   c=self.n('B');n|=(c&127)<<s;s+=7
   if c<128:return n
 def st(self):
  n=self.vi();s=self.b[self.p:self.p+n].decode();self.p+=n;return s
 def ch(self):
  for n in range(1,5):
   try:s=self.b[self.p:self.p+n].decode('utf-8');self.p+=n;return s
   except UnicodeDecodeError:pass
 def obj(self):return self.vi()
def load(p):
 r=Reader(Path(p).read_bytes());readers=[(r.st(),r.n('i')) for _ in range(r.vi())];shared=r.vi();root=r.obj();texreader=r.obj();fmt,w,h,levels=r.n('4i');textures=[]
 for _ in range(levels):
  n=r.n('i');textures.append(r.b[r.p:r.p+n]);r.p+=n
 arrays=[]
 for form in ['4i','4i','char']:
  typ=r.obj();n=r.n('i');a=[r.ch() if form=='char' else r.n(form) for _ in range(n)];arrays.append((typ,a))
 line,spacing=r.n('if');typ=r.obj();n=r.n('i');kern=[r.n('3f') for _ in range(n)];has=r.n('?');default=r.ch() if has else None
 assert r.p==len(r.b),(r.p,len(r.b))
 return locals()
def vi(n):
 b=bytearray()
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return bytes(b)

def st(s):b=s.encode();return vi(len(b))+b

def pack(fmt,*v):return struct.pack('<'+fmt,*v)

def save(f,tex,entries,path):
 b=vi(len(f['readers']))
 for s,v in f['readers']:b+=st(s)+pack('i',v)
 b+=vi(0)+vi(f['root'])+vi(f['texreader'])+pack('4i',0,tex.width,tex.height,1)
 pixels=tex.tobytes();b+=pack('i',len(pixels))+pixels
 keys=sorted(entries)
 for j,form in [(0,'4i'),(1,'4i'),(2,'char')]:
  b+=vi(f['arrays'][j][0])+pack('i',len(keys))
  for c in keys:b+=c.encode('utf-8') if j==2 else pack(form,*entries[c][j])
 b+=pack('if',f['line'],f['spacing'])+vi(f['typ'])+pack('i',len(keys))
 for c in keys:b+=pack('3f',*entries[c][2])
 b+=pack('?',f['has'])+(f['default'].encode() if f['has'] else b'')
 path.write_bytes(f['r'].b[:6]+pack('i',10+len(b))+b)
