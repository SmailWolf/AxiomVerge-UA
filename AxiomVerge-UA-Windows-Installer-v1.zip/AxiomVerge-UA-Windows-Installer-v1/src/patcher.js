#!/usr/bin/env node
/* Builds a local patch from the user's own, unmodified game installation.
 * No game executable or game font assets are distributed by this project.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
global.JSZip = require('jszip');
require('./glyphs.js');
const V = require('./verge-core.js');

const ORIGINAL_EXE_SHA256 = 'aea794eb9788ebcf32cbc5d86db37c0a73967d1ce359da59d478a40191cd4ebd';
const root = path.resolve(process.argv[2] || '');
const exePath = path.join(root, 'AxiomVerge.exe');
if (!process.argv[2] || !fs.existsSync(exePath)) {
  console.error('Використання: npm run patch -- "/шлях/до/Axiom Verge"');
  process.exit(2);
}

function hash(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function ensure(condition, message) { if (!condition) throw new Error(message); }

(async () => {
  const original = new Uint8Array(fs.readFileSync(exePath));
  ensure(hash(original) === ORIGINAL_EXE_SHA256,
    'Версія AxiomVerge.exe не збігається з перевіреною оригінальною версією. Файл не змінено.');
  const info = V.peInfo(original);
  const resource = info.resources.find(r => /Content\.zip$/i.test(r.name));
  ensure(resource, 'У EXE не знайдено вбудований Content.zip.');
  const content = await JSZip.loadAsync(resource.data, { checkCRC32: true });
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'axiom-verge-ua-'));
  const rawXml = path.join(temp, 'original');
  const editedXml = path.join(temp, 'translated');
  fs.mkdirSync(rawXml, { recursive: true });
  for (const name of Object.keys(content.files)) {
    if (/^Text\/[^/]+_English\.xml$/i.test(name)) {
      fs.writeFileSync(path.join(rawXml, path.basename(name)), await content.file(name).async('nodebuffer'));
    }
  }
  const python = process.env.PYTHON || 'python3';
  const py = spawnSync(python, [path.join(__dirname, 'patch_xml.py'), rawXml, editedXml,
    path.join(__dirname, '..', 'translations')], { encoding: 'utf8' });
  if (py.status !== 0) throw new Error(py.stderr || 'Не вдалося застосувати переклади.');
  for (const name of fs.readdirSync(editedXml)) {
    content.file(`Text/${name}`, fs.readFileSync(path.join(editedXml, name)), { createFolders: false });
  }
  const archive = await content.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 9 } });
  const rebuilt = await JSZip.loadAsync(archive, { checkCRC32: true });
  ensure(Object.keys(rebuilt.files).length === Object.keys(content.files).length,
    'Структура внутрішнього архіву змінилася. Перервано.');
  const patched = V.replaceResource(original, resource.name, archive, 1);
  const output = path.join(root, 'build', 'Axiom Verge UA patch');
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(path.join(output, 'AxiomVerge.exe'), patched.bytes);
  const sourceFonts = path.join(root, 'Content/Art/Textures/UI/Fonts');
  const outputFonts = path.join(output, 'Content/Art/Textures/UI/Fonts');
  const fontBuild = spawnSync(python, [path.join(__dirname, 'font_builder.py'), sourceFonts, outputFonts, path.join(output, 'font-report.json')], { encoding: 'utf8' });
  if (fontBuild.status !== 0) throw new Error(fontBuild.stderr || 'Не вдалося перебудувати українські шрифти.');
  const fontReportPath = path.join(output, 'font-report.json');
  const fontReport = JSON.parse(fs.readFileSync(fontReportPath, 'utf8'));
  for (const required of ['LucidaConsole6XNA.xnb', 'LucidaConsole8XNA.xnb', 'Moire16XNA.xnb']) {
    ensure(fs.existsSync(path.join(outputFonts, required)), `Не знайдено потрібний шрифт ${required}.`);
  }
  fs.writeFileSync(path.join(output, 'README-UA.txt'),
    'Патч української локалізації для Axiom Verge 1. Заміни EXE та файли шрифтів з цієї папки у корені гри. Перед заміною зроби резервну копію.\n');
  fs.writeFileSync(path.join(output, 'build-report.json'), JSON.stringify({
    game: 'Axiom Verge (2015)', originalExeSha256: hash(original),
    patchedExeSha256: hash(patched.bytes), fontFiles: fontReport, binaryChanges: patched.changes,
    translations: py.stdout.trim()
  }, null, 2));
  fs.rmSync(temp, { recursive: true, force: true });
  console.log(`Патч зібрано локально: ${output}`);
  console.log('До цього проєкту оригінальний EXE і файли шрифтів не додаються.');
})().catch(error => { console.error('Помилка: ' + error.message); process.exit(1); });
