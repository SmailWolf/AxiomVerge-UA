from pathlib import Path
import sys,ast,struct,json,hashlib,shutil
sys.path.insert(0,str(Path(__file__).resolve().parent))
from font_xnb import load,vi,st,pack,save
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent.parent/'fonts'
SOURCE=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();REPORT=Path(sys.argv[3]).resolve();OUT.mkdir(parents=True,exist_ok=True)
def cmap(path):
 b=path.read_bytes();tables={}
 for i in range(struct.unpack_from('>H',b,4)[0]):
  tag,_,off,size=struct.unpack_from('>4sIII',b,12+16*i);tables[tag]=b[off:off+size]
 b=tables[b'cmap']; chars=set()
 for i in range(struct.unpack_from('>H',b,2)[0]):
  plat,enc,off=struct.unpack_from('>HHI',b,4+8*i);fmt=struct.unpack_from('>H',b,off)[0]
  if fmt==4:
   n=struct.unpack_from('>H',b,off+6)[0]//2;ends=struct.unpack_from('>'+str(n)+'H',b,off+14);starts=struct.unpack_from('>'+str(n)+'H',b,off+16+2*n)
   for start,end in zip(starts,ends):chars.update(chr(c) for c in range(start,min(end,65534)+1))
  elif fmt==12:
   for k in range(struct.unpack_from('>I',b,off+12)[0]):
    start,end,g=struct.unpack_from('>III',b,off+16+12*k);chars.update(chr(c) for c in range(start,end+1))
 return chars
fonts={name:ImageFont.truetype(str(ROOT/(name+'.ttf')),8) for name in ['Tiny5-Regular','PressStart2P-Regular']}
supported={name:cmap(ROOT/(name+'.ttf')) for name in fonts}
uk='АБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯабвгґдеєжзиіїйклмнопрстуфхцчшщьюя'
report=[]
for filename,size in [('LucidaConsole6XNA.xnb',6),('LucidaConsole8XNA.xnb',8),('Moire16XNA.xnb',16)]:
 f=load(SOURCE/filename); oldtex=Image.frombytes('RGBA',(f['w'],f['h']),f['textures'][0]); entries={};imgs={}
 name='Tiny5-Regular' if size==6 else 'PressStart2P-Regular';font=fonts[name]
 # Other scripts remain available through the original glyphs.
 chars=set(f['arrays'][2][1])|set(uk)|set('’–—…')
 for c in chars:
  replace=c in supported[name] and (0x20<=ord(c)<=0x24f or 0x370<=ord(c)<=0x52f or c in '’–—…')
  if replace:
   base=Image.new('L',(6 if size==6 else 8,8));d=ImageDraw.Draw(base)
   if size==6:
    bbox=font.getbbox(c);width=bbox[2]-bbox[0];x=(6-width)//2-bbox[0]
    d.text((x,-1),c,font=font,fill=255,stroke_width=0)
    if c in 'іiї':
     d.rectangle((0,0,5,7),fill=0)
     if c=='ї':d.point([(1,0),(3,0)],fill=255)
     else:d.point((2,0),fill=255)
     d.line((2,2,2,5),fill=255)
    if c in 'ІIЇ':
     d.rectangle((0,0,5,7),fill=0);d.line((2,2,2,5),fill=255)
     d.line((1,2,3,2),fill=255);d.line((1,5,3,5),fill=255)
     if c=='Ї':d.point([(1,0),(3,0)],fill=255)
    if c in 'Йй':
     d.rectangle((0,0,5,7),fill=0);d.text((0,0),'И' if c=='Й' else 'и',font=font,fill=255);d.point([(1,0),(3,0),(2,1)],fill=255)
    # Wide Cyrillic descenders get a dedicated 5-pixel shape, leaving a gap.
    pats={'Д':[6,10,10,10,10,31,17],'д':[0,0,6,10,10,31,17],'Ц':[18,18,18,18,18,31,1],'ц':[0,0,18,18,18,31,1],'Щ':[21,21,21,21,21,31,1],'щ':[0,0,21,21,21,31,1]}
    if c in pats:
     d.rectangle((0,0,5,7),fill=0)
     for y,row in enumerate(pats[c]):
      for x in range(5):
       if row&(1<<(4-x)):d.point((x,y),fill=255)
   else:
    d.text((0,0),c,font=font,fill=255)
    if c in 'іiї':
     d.rectangle((0,0,7,7),fill=0)
     if c=='ї':d.rectangle((1,0,2,0),fill=255);d.rectangle((5,0,6,0),fill=255)
     else:d.rectangle((3,0,4,0),fill=255)
     d.rectangle((3,2,4,6),fill=255)
    if c in 'ІIЇ':
     d.rectangle((0,0,7,7),fill=0);d.rectangle((3,2 if c=='Ї' else 0,4,6),fill=255)
     d.rectangle((1,2 if c=='Ї' else 0,6,2 if c=='Ї' else 0),fill=255);d.rectangle((1,6,6,6),fill=255)
     if c=='Ї':d.rectangle((1,0,2,0),fill=255);d.rectangle((5,0,6,0),fill=255)
    if c in 'Йй':
     # A shaped breve and a complete diagonal body sharing the normal baseline.
     rows=([0x44,0x38,0xc6,0xce,0xde,0xe6,0xc6,0] if c=='Й' else [0x44,0x38,0,0xc6,0xce,0xde,0xe6,0])
     d.rectangle((0,0,7,7),fill=0)
     for y,row in enumerate(rows):
      for x in range(8):
       if row&(1<<(7-x)):d.point((x,y),fill=255)
   # No antialiasing: one game pixel is one solid bitmap pixel.
   base=base.point(lambda a:255 if a>=128 else 0)
   rgba=Image.new('RGBA',base.size,(255,255,255,0));rgba.putalpha(base)
   if size==16:rgba=rgba.resize((16,16),Image.Resampling.NEAREST)
   imgs[c]=rgba;entries[c]=(None,(0,4 if size==16 else 0,size,f['line']),(0.,float(size),0.))
  else:
   i=f['arrays'][2][1].index(c);r=f['arrays'][0][1][i];x,y,w,h=r;imgs[c]=oldtex.crop((x,y,x+w,y+h));entries[c]=(None,f['arrays'][1][1][i],f['kern'][i])
 width=512;positions={};x=y=1;row=0
 for c in sorted(chars):
  g=imgs[c]
  if x+g.width+1>width:x=1;y+=row+1;row=0
  positions[c]=(x,y,g.width,g.height);x+=g.width+1;row=max(row,g.height)
 height=1
 while height<y+row+1:height*=2
 tex=Image.new('RGBA',(width,height))
 for c in chars:
  x,y,w,h=positions[c];tex.alpha_composite(imgs[c],(x,y));entries[c]=(positions[c],entries[c][1],entries[c][2])
 save(f,tex,entries,OUT/filename)
 verified=load(OUT/filename)
 assert set(uk)<=set(verified['arrays'][2][1]);assert imgs['і'].tobytes()!=imgs['1'].tobytes()
 assert set(tex.getchannel('A').getdata())<={0,255}
 report.append({'font':filename,'line_spacing':f['line'],'cell_width':size,'changed_glyphs':sum(entries[c][2]==(0.,float(size),0.) for c in chars),'sha256':hashlib.sha256((OUT/filename).read_bytes()).hexdigest()})
REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
