$ErrorActionPreference = 'Stop'
$Project = $PSScriptRoot
$ExpectedExeHash = 'aea794eb9788ebcf32cbc5d86db37c0a73967d1ce359da59d478a40191cd4ebd'
$FontNames = @('LucidaConsole6XNA.xnb', 'LucidaConsole8XNA.xnb', 'Moire16XNA.xnb')

function Get-FileHashHex([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Find-SteamGame {
    $steamRoots = @()
    foreach ($regPath in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        try {
            $properties = Get-ItemProperty -LiteralPath $regPath -ErrorAction Stop
            foreach ($propertyName in @('InstallPath', 'SteamPath')) {
                $value = $properties.$propertyName
                if ($value) { $steamRoots += $value }
            }
        } catch {}
    }
    if (${env:ProgramFiles(x86)}) { $steamRoots += (Join-Path ${env:ProgramFiles(x86)} 'Steam') }
    if ($env:ProgramFiles) { $steamRoots += (Join-Path $env:ProgramFiles 'Steam') }

    $libraries = @()
    foreach ($steam in ($steamRoots | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $steam) { $libraries += $steam }
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            $text = Get-Content -LiteralPath $vdf -Raw
            foreach ($match in [regex]::Matches($text, '"path"\s+"([^"]+)"')) {
                $libraries += $match.Groups[1].Value.Replace('\\', '\')
            }
        }
    }
    foreach ($library in ($libraries | Select-Object -Unique)) {
        $candidate = Join-Path $library 'steamapps\common\Axiom Verge'
        if (Test-Path -LiteralPath (Join-Path $candidate 'AxiomVerge.exe')) { return $candidate }
    }
    return $null
}

try {
    $node = Get-Command node.exe -ErrorAction SilentlyContinue
    $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if (!$node -or !$npm -or !$py) {
        throw 'Install Node.js and Python 3 first, making sure the Python launcher (py) is enabled. Then double-click this installer again.'
    }

    $game = Find-SteamGame
    if (!$game) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Select the Axiom Verge game folder containing AxiomVerge.exe'
        $dialog.ShowNewFolderButton = $false
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            Write-Host 'Installation cancelled.'
            exit 1
        }
        $game = $dialog.SelectedPath
    }
    $game = (Resolve-Path -LiteralPath $game).Path
    $exe = Join-Path $game 'AxiomVerge.exe'
    if (!(Test-Path -LiteralPath $exe)) { throw 'The selected folder does not contain AxiomVerge.exe.' }

    $backup = Join-Path $game 'Axiom Verge UA backup'
    $statePath = Join-Path $backup 'install-state.json'
    $fontSource = Join-Path $game 'Content\Art\Textures\UI\Fonts'
    if (!(Test-Path -LiteralPath $fontSource)) { throw 'The selected folder does not contain the original game fonts.' }
    foreach ($font in $FontNames) {
        if (!(Test-Path -LiteralPath (Join-Path $fontSource $font))) { throw "Required original font is missing: $font" }
    }

    Write-Host "Game folder: $game"
    $answer = Read-Host 'Continue and install the Ukrainian patch here? (Y/N)'
    if ($answer -notin @('Y', 'y', 'YES', 'yes')) {
        Write-Host 'Installation cancelled.'
        exit 1
    }

    if (Test-Path -LiteralPath $statePath) {
        $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
        if ((Get-FileHashHex $exe) -ne $state.installedExeSha256) {
            throw 'The game executable has changed since this patch was installed. Restore your own changes or original backup first; the installer stopped without overwriting it.'
        }
        if ((Get-FileHashHex (Join-Path $backup 'AxiomVerge.exe')) -ne $ExpectedExeHash) {
            throw 'The saved original EXE backup does not match the supported game version. No files were changed.'
        }
        Copy-Item -LiteralPath (Join-Path $backup 'AxiomVerge.exe') -Destination $exe -Force
        foreach ($font in $FontNames) {
            Copy-Item -LiteralPath (Join-Path $backup $font) -Destination (Join-Path $fontSource $font) -Force
        }
        Remove-Item -LiteralPath $statePath -Force
    } elseif ((Get-FileHashHex $exe) -ne $ExpectedExeHash) {
        throw 'This game version is not supported. The installer only accepts the verified original AxiomVerge.exe and made no changes.'
    }

    Write-Host "Game folder: $game"
    Write-Host 'Preparing the patch. The first run may download JSZip and Pillow.'
    Push-Location $Project
    try {
        if (!(Test-Path -LiteralPath (Join-Path $Project 'node_modules\jszip'))) {
            & $npm.Source install --omit=dev
            if ($LASTEXITCODE -ne 0) { throw 'npm could not install JSZip.' }
        }
        & $py.Source -3 -m pip install -r (Join-Path $Project 'requirements.txt')
        if ($LASTEXITCODE -ne 0) { throw 'Python could not install Pillow.' }
        $env:PYTHON = 'py'
        & $npm.Source run patch -- $game
        if ($LASTEXITCODE -ne 0) { throw 'The patch could not be built. See the error above.' }
    } finally {
        Pop-Location
    }

    $built = Join-Path $game 'build\Axiom Verge UA patch'
    if (!(Test-Path -LiteralPath (Join-Path $built 'AxiomVerge.exe'))) { throw 'The patch build did not produce AxiomVerge.exe.' }
    $builtFonts = Join-Path $built 'Content\Art\Textures\UI\Fonts'
    foreach ($font in $FontNames) {
        if (!(Test-Path -LiteralPath (Join-Path $builtFonts $font))) { throw "The patch build is missing $font." }
    }

    if (!(Test-Path -LiteralPath $backup)) { New-Item -ItemType Directory -Path $backup | Out-Null }
    if (!(Test-Path -LiteralPath (Join-Path $backup 'AxiomVerge.exe'))) {
        Copy-Item -LiteralPath $exe -Destination (Join-Path $backup 'AxiomVerge.exe')
    }
    foreach ($font in $FontNames) {
        if (!(Test-Path -LiteralPath (Join-Path $backup $font))) {
            Copy-Item -LiteralPath (Join-Path $fontSource $font) -Destination (Join-Path $backup $font)
        }
    }

    Copy-Item -LiteralPath (Join-Path $built 'AxiomVerge.exe') -Destination $exe -Force
    foreach ($font in $FontNames) {
        Copy-Item -LiteralPath (Join-Path $builtFonts $font) -Destination (Join-Path $fontSource $font) -Force
    }
    $installedHash = Get-FileHashHex $exe
    @{ installedExeSha256 = $installedHash } | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding UTF8
    Write-Host ''
    Write-Host 'Axiom Verge українською встановлено!' -ForegroundColor Green
    Write-Host "Оригінальні файли збережено в: $backup"
    Write-Host 'Для запуску гри закрийте це вікно та відкрийте гру звичайним способом.'
    Read-Host 'Натисніть Enter, щоб закрити'
    exit 0
} catch {
    Write-Host "Помилка встановлення: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host 'Натисніть Enter, щоб закрити'
    exit 1
}
